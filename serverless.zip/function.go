package serverless

import (
	"context"
	"database/sql"
	_ "github.com/lib/pq"
	"encoding/json"
	"fmt"
	"github.com/GoogleCloudPlatform/functions-framework-go/functions"
	"github.com/cloudevents/sdk-go/v2/event"
	"github.com/google/uuid"
	"github.com/mailgun/mailgun-go/v4"
	"github.com/rs/zerolog/log"
	"os"
	"time"
)

func init() {
	functions.CloudEvent("ConsumeSendEmailEvent", consumeEvent)
}

type MessagePublishedData struct {
	Message PubSubMessage
}

type PubSubMessage struct {
	Data []byte `json:"data"`
}

type EmailVerification struct {
	EmailVerificationUUID uuid.UUID `json:"emailVerificationUUID"`
	VerificationLink      string    `json:"verificationLink"`
	Username              string    `json:"username"`
	FirstName             string    `json:"firstName"`
	LastName              string    `json:"lastName"`
	UserID                uuid.UUID `json:"userID"`
}

type Email struct {
	ID                      uuid.UUID `gorm:"type:uuid;default:uuid_generate_v4();primary_key"`
	CreatedAt               time.Time
	UpdatedAt               time.Time
	EmailVerificationUUID   uuid.UUID `gorm:"type:uuid;default:uuid_generate_v4()"`
	EmailVerificationExpiry time.Time
	UserID                  uuid.UUID `gorm:"type:uuid;foreignkey:ID"`
}

func connectToPostgres() (*sql.DB, error) {
	DB_CONN_STR := os.Getenv("DB_CONN_STR_FUNC")
	DB_CONN_STR = DB_CONN_STR + "?sslmode=disable"

	db, err := sql.Open("postgres", DB_CONN_STR)
	if err != nil {
		fmt.Println(err)
		log.Error().Err(err).Msg("Error connecting to the database")
		return nil, err
	}

	// Check if the database connection is successful
	err = db.Ping()
	if err != nil {
		log.Error().Err(err).Msg("Error pinging the database")
		return nil, err
	}

	log.Info().Msg("Connected to the database")
	return db, nil
}

// consumeEvent consumes a CloudEvent message and extracts the Pub/Sub message.
func consumeEvent(ctx context.Context, e event.Event) error {
	var msgData MessagePublishedData

	if err := e.DataAs(&msgData); err != nil {
		log.Error().Err(err).Msg("Error unmarshalling the Pub/Sub message")
		return err
	}
	fmt.Printf("Raw event data: %s\n", string(e.Data()))
	fmt.Println("Event type: ", string(msgData.Message.Data))
	temp := string(msgData.Message.Data)
	t2 := []byte(temp)

	var pubSubMsg EmailVerification
	if err := json.Unmarshal(t2, &pubSubMsg); err != nil {
		log.Error().Err(err).Msg("Error unmarshalling the decoded data")
		return err
	}

	db, err := connectToPostgres()
	if err != nil {
		log.Error().Err(err).Msg("Error connecting to the database")
		return err
	}
	defer db.Close()

	// Prepare the SQL statement
	stmt := `INSERT INTO emails (email_verification_expiry, user_id) VALUES ($1, $2) RETURNING email_verification_uuid`
	expiry := time.Now().Add(time.Minute * 2) // Set the expiry time to 2 Minutes from now

	// Execute the SQL statement and get the generated EmailVerificationUUID
	var emailVerificationUUID uuid.UUID
	err = db.QueryRow(stmt, expiry, pubSubMsg.UserID).Scan(&emailVerificationUUID)
	if err != nil {
		log.Error().Err(err).Msg("Error executing the SQL statement")
		return err
	}

	pubSubMsg.VerificationLink += emailVerificationUUID.String()
	log.Printf("Consumed Pub/Sub message is %v", pubSubMsg)
	// Send email using MailGun's API
	err = sendEmail(pubSubMsg)
	if err != nil {
		log.Printf("sendEmail: %v", err)
		return err
	}

	log.Info().Msg("Email sent successfully")
	return nil
}

// sendEmail sends an email using MailGun's API.
func sendEmail(msg EmailVerification) error {
	// Draft the email body
	emailBody := draftEmailBody(msg)
	log.Info().Msg("Drafted email body")
	// Create an instance of the Mailgun client
	domain := os.Getenv("MAILGUN_DOMAIN")
	apiKey := os.Getenv("MAILGUN_API_KEY")
	mg := mailgun.NewMailgun(domain, apiKey)

	// Create a new message
	message := mg.NewMessage(
		"noreply@girishkulkarni.me",
		"Verification Link",
		"This is a verification email sent from the Cloud Function.",
		msg.Username,
	)

	// Set the HTML body of the email
	message.SetHtml(emailBody)

	// Send the message
	m, _, err := mg.Send(context.Background(), message)
	if err != nil {
		log.Error().Err(err).Msg("Error sending the email")
		return err
	}

	log.Info().Msgf("Email sent successfully with ID: %s", msg.VerificationLink)
	log.Info().Msgf("Email sent successfully with Message: %s", m)

	return nil
}

// draftEmailBody drafts the email body using the provided PubSubMessage.
func draftEmailBody(msg EmailVerification) string {
	// Construct the email body
	emailBody := fmt.Sprintf(`
    <html>
    <head>
      <style>
        body {
          font-family: Arial, sans-serif;
        }
        .container {
          width: 80%%;
          margin: auto;
          padding: 20px;
          border: 1px solid #ddd;
          border-radius: 5px;
        }
        .greeting {
          font-size: 20px;
          color: #444;
        }
        .link {
          display: inline-block;
          margin-top: 20px;
          padding: 10px 20px;
          background-color: #007BFF;
          color: white;
          text-decoration: none;
          border-radius: 5px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <p class="greeting">Hello %s %s,</p>
        <p>Your verification link is: <a class="link" href="%s">Click Here</a></p>
      </div>
    </body>
    </html>
  `, msg.FirstName, msg.LastName, msg.VerificationLink)

	return emailBody
}
